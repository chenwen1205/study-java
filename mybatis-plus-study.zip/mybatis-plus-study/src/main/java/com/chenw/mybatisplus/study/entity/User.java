package com.chenw.mybatisplus.study.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.Date;
import lombok.Data;

/**
* @author chenw
* date 2021/6/7 16:51
*/
@ApiModel(value="com.chenw.mybatisplus.study.entity.User")
@Data
@TableName(value = "user")
public class User {
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.INPUT)
    @ApiModelProperty(value="主键")
    private Long id;

    /**
     * 姓名
     */
    @TableField(value = "name")
    @ApiModelProperty(value="姓名")
    private String name;

    /**
     * 年龄
     */
    @TableField(value = "age")
    @ApiModelProperty(value="年龄")
    private Integer age;

    /**
     * 邮箱
     */
    @TableField(value = "email")
    @ApiModelProperty(value="邮箱")
    private String email;

    /**
     * 直属上级id
     */
    @TableField(value = "manager_id")
    @ApiModelProperty(value="直属上级id")
    private Long managerId;

    /**
     * 创建时间
     */
    @TableField(value = "create_time")
    @ApiModelProperty(value="创建时间")
    private Date createTime;
}
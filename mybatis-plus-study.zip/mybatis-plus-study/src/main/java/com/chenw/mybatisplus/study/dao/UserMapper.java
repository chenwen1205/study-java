package com.chenw.mybatisplus.study.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.chenw.mybatisplus.study.entity.User;
import org.apache.ibatis.annotations.Mapper;

/**
* @author chenw
* date 2021/6/7 16:51
*/
@Mapper
public interface UserMapper extends BaseMapper<User> {
}
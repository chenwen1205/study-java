package com.chenw.mybatisplus.study.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.chenw.mybatisplus.study.dao.UserMapper;
import com.chenw.mybatisplus.study.entity.User;
import com.chenw.mybatisplus.study.service.UserService;
/**
* @author chenw
* date 2021/6/7 16:51
*/
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService{

}

package com.chenw.mybatisplus.study.service;

import com.chenw.mybatisplus.study.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;
    /**
* @author chenw
* date 2021/6/7 16:51
*/
public interface UserService extends IService<User>{


}

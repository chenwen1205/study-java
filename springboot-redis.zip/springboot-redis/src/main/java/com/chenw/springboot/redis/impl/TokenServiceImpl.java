package com.chenw.springboot.redis.impl;

import com.chenw.springboot.redis.bean.RedisKeyPrefix;
import com.chenw.springboot.redis.utils.RedisUtil;
import com.chenw.springboot.redis.exception.ApiResult;
import com.chenw.springboot.redis.exception.BusinessException;
import com.chenw.springboot.redis.service.TokenService;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.UUID;

/**
 * @author chenw
 * date 2021/6/8 14:02
 */
@Service
public class TokenServiceImpl implements TokenService {
    @Autowired
    private RedisUtil redisUtil;

    /**
     * 创建token
     *
     * @return
     */
    @Override
    public String createToken() {
        String str = UUID.randomUUID().toString().replace("-", "");
        StringBuilder token = new StringBuilder();
        try {
            token.append(RedisKeyPrefix.TOKEN_PREFIX).append(str);
            redisUtil.setEx(token.toString(), token.toString(), 10000L);
            boolean empty = StringUtils.isEmpty(token.toString());
            if (!empty) {
                return token.toString();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    /**
     * 检验token
     *
     * @param request
     * @return
     */
    @Override
    public boolean checkToken(HttpServletRequest request) throws Exception {

        String token = request.getHeader(RedisKeyPrefix.TOKEN_NAME);
        // header中不存在token
        if (StringUtils.isEmpty(token)) {
            token = request.getParameter(RedisKeyPrefix.TOKEN_NAME);
            // parameter中也不存在token
            if (StringUtils.isEmpty(token)) {
                throw new BusinessException(ApiResult.BADARGUMENT);
            }
        }

        if (!redisUtil.exists(token)) {
            throw new BusinessException(ApiResult.REPETITIVE_OPERATION);
        }

        boolean remove = redisUtil.remove(token);
        if (!remove) {
            throw new BusinessException(ApiResult.REPETITIVE_OPERATION);
        }
        return true;
    }
}

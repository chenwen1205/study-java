package com.chenw.springboot.redis.service;

import javax.servlet.http.HttpServletRequest;

/**
 * @author chenw
 * date 2021/6/8 13:53
 */
public interface TokenService {
    /**
     * 创建token
     *
     * @return
     */
    String createToken();

    /**
     * 检验token
     * @param request
     * @return boolean
     */
    boolean checkToken(HttpServletRequest request) throws Exception;
}

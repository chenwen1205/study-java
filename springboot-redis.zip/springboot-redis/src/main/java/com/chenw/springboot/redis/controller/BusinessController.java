package com.chenw.springboot.redis.controller;

import com.chenw.springboot.redis.annotation.AutoIdempotent;
import com.chenw.springboot.redis.service.TokenService;
import com.chenw.springboot.redis.utils.ResponseUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author chenw
 * date 2021/6/8 14:37
 */
@RestController
public class BusinessController {


    @Autowired
    private TokenService tokenService;

    @GetMapping("/get/token")
    public Object  getToken(){
        String token = tokenService.createToken();
        return ResponseUtil.ok(token) ;
    }


    @AutoIdempotent
    @GetMapping("/test/Idempotence")
    public Object testIdempotence() {
        String token = "接口幂等性测试";
        return ResponseUtil.ok(token) ;
    }
}
